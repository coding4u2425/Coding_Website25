# Calculator
A calculator using JavaScript is a web application that allows users to perform basic arithmetic operations like addition, subtraction, multiplication, and division.
