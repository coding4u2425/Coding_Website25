import emoji

text_with_emoji = "I ❤️  Python!"

emoji_as_text = emoji.demojize(text_with_emoji)

print("Emoji:", text_with_emoji)
print("Emoji to Text:", emoji_as_text)