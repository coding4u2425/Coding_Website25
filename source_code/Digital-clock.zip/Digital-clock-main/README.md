# Digital-clock
A digital clock is a kind of device that uses digits to show the current time in numerical form. Digital clocks are frequently found in a wide range of electronic devices, including computers, microwave ovens.
